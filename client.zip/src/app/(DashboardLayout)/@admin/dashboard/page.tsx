import { DollarSign, ShoppingBag, Users, UtensilsCrossed } from "lucide-react";
import DashboardHeader from "@/components/modules/dashboard/DashboardHeader";
import StatCard from "@/components/modules/dashboard/StatCard";
import OrderStatusBadge from "@/components/modules/dashboard/OrderStatusBadge";
import { getOrders } from "@/services/orders";
import { getAllUsers } from "@/services/users";
import { getAllProviders } from "@/services/providers";
import { formatCurrency, formatDate } from "@/lib/format";

const MONTHLY = [
  ["Jan", "12k", 40],
  ["Feb", "18k", 60],
  ["Mar", "15k", 50],
  ["Apr", "22k", 73],
  ["May", "28k", 93],
  ["Jun", "30k", 100],
];

export default async function AdminDashboardPage() {
  const [{ data: users }, { data: orders }, { data: providerData }] =
    await Promise.all([getAllUsers(), getOrders(), getAllProviders({ limit: "100" })]);
  const providers = providerData?.providers || [];
  const revenue = (orders || [])
    .filter((order) => order.status === "DELIVERED")
    .reduce((sum, order) => sum + Number(order.totalPrice || 0), 0);

  return (
    <div>
      <DashboardHeader
        title="Admin Dashboard"
        subtitle="Platform overview and management"
      />
      <div className="space-y-6 p-4 sm:p-6">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard
            label="Total Users"
            value={users?.length || 0}
            sub={`${users?.filter((user) => user.role === "CUSTOMER").length || 0} customers - ${users?.filter((user) => user.role === "PROVIDER").length || 0} providers`}
            icon={Users}
            iconBg="bg-purple-50"
            iconColor="text-purple-600"
          />
          <StatCard
            label="Total Orders"
            value={orders?.length || 0}
            sub="All time"
            icon={ShoppingBag}
          />
          <StatCard
            label="Platform Revenue"
            value={formatCurrency(revenue)}
            sub="Delivered orders"
            icon={DollarSign}
            iconBg="bg-green-50"
            iconColor="text-green-600"
          />
          <StatCard
            label="Restaurants"
            value={providers.length}
            sub="Active providers"
            icon={UtensilsCrossed}
            iconBg="bg-amber-50"
            iconColor="text-amber-600"
          />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="rounded-xl border border-fh-cream-dark bg-white p-6 lg:col-span-2">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="font-semibold text-fh-green-deep">
                Monthly Revenue
              </h2>
              <span className="rounded-full bg-green-50 px-2.5 py-1 text-xs font-semibold text-green-600">
                Stable growth
              </span>
            </div>
            <div className="flex h-48 items-end gap-3">
              {MONTHLY.map(([month, value, height]) => (
                <div key={month} className="flex flex-1 flex-col items-center gap-2">
                  <span className="text-xs font-medium text-fh-green-muted">
                    {value}
                  </span>
                  <div
                    className="w-full cursor-pointer rounded-t-lg bg-gradient-to-t from-fh-green-deep to-fh-green-muted transition-all duration-500 hover:from-fh-coral hover:to-fh-coral-light"
                    style={{ height: `${Number(height)}%` }}
                  />
                  <span className="text-xs text-fh-green-muted">{month}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl bg-fh-green-deep p-5 text-white">
              <p className="mb-1 text-sm font-medium text-white/60">
                Today&apos;s Orders
              </p>
              <p className="font-display text-4xl font-bold">
                {
                  (orders || []).filter(
                    (order) =>
                      new Date(order.createdAt).toDateString() ===
                      new Date().toDateString(),
                  ).length
                }
              </p>
            </div>
            <div className="rounded-xl border border-fh-cream-dark bg-white p-5">
              <p className="mb-3 text-sm font-medium text-fh-green-muted">
                Platform Health
              </p>
              {[
                ["Order Success Rate", "96%", "text-green-600"],
                ["Avg. Delivery Time", "32 min", "text-amber-600"],
                ["User Satisfaction", "4.8/5", "text-yellow-500"],
              ].map(([label, value, color]) => (
                <div
                  key={label}
                  className="flex items-center justify-between border-b border-fh-cream-dark py-2.5 last:border-0"
                >
                  <span className="text-sm text-fh-green-muted">{label}</span>
                  <span className={`text-sm font-bold ${color}`}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-xl border border-fh-cream-dark bg-white">
          <div className="border-b border-fh-cream-dark px-6 py-4">
            <h2 className="font-semibold text-fh-green-deep">Recent Orders</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-fh-cream-dark bg-fh-cream/50">
                  {["Order ID", "Customer", "Restaurant", "Items", "Total", "Status", "Date"].map(
                    (heading) => (
                      <th
                        key={heading}
                        className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-fh-green-muted"
                      >
                        {heading}
                      </th>
                    ),
                  )}
                </tr>
              </thead>
              <tbody>
                {(orders || []).slice(0, 8).map((order) => (
                  <tr
                    key={order.id}
                    className="border-b border-fh-cream-dark transition-colors hover:bg-fh-cream/30"
                  >
                    <td className="px-5 py-4 font-mono text-xs font-medium text-fh-green-deep">
                      {order.id.slice(0, 8)}
                    </td>
                    <td className="px-5 py-4 font-medium text-fh-green-deep">
                      {order.customer?.name || "Customer"}
                    </td>
                    <td className="px-5 py-4 text-fh-green-muted">
                      {order.provider?.restaurantName || "FoodHub"}
                    </td>
                    <td className="px-5 py-4 text-fh-green-muted">
                      {order.items
                        .map((item) => `${item.mealName} x${item.quantity}`)
                        .join(", ")}
                    </td>
                    <td className="px-5 py-4 font-display font-bold text-fh-green-deep">
                      {formatCurrency(order.totalPrice)}
                    </td>
                    <td className="px-5 py-4">
                      <OrderStatusBadge status={order.status} />
                    </td>
                    <td className="px-5 py-4 text-xs text-fh-green-muted">
                      {formatDate(order.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
